import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    precision_recall_curve,
    roc_auc_score,
    roc_curve,
    f1_score,
    accuracy_score,
    recall_score,
    precision_score,
)

def get_true_pos(y, pred, th=0.5):
    pred_t = (pred > th)
    return np.sum((pred_t == True) & (y == 1))

def get_true_neg(y, pred, th=0.5):
    pred_t = (pred > th)
    return np.sum((pred_t == False) & (y == 0))

def get_false_neg(y, pred, th=0.5):
    pred_t = (pred > th)
    return np.sum((pred_t == False) & (y == 1))

def get_false_pos(y, pred, th=0.5):
    pred_t = (pred > th)
    return np.sum((pred_t == True) & (y == 0))

def get_performance_metrics(y, pred, class_labels, thresholds=None, acc=None, **kwargs):
    """
    Calculate various performance metrics for classification results.
    
    Args:
        y: numpy array of shape (n_samples, n_classes) with ground truth labels
        pred: numpy array of shape (n_samples, n_classes) with prediction probabilities
        class_labels: list of class names
        thresholds: optional list of threshold values for each class, defaults to 0.5 for all classes
        acc: optional custom accuracy function
        **kwargs: additional keyword arguments for future extensibility
    
    Returns:
        DataFrame with performance metrics for each class
    """
    if thresholds is None:
        thresholds = [0.5] * len(class_labels)
    elif len(thresholds) != len(class_labels):
        raise ValueError("Length of thresholds must match number of class labels.")

    # Default accuracy function if none provided
    if acc is None:
        acc_func = lambda y_true, y_pred, th: accuracy_score(y_true, y_pred > th)
    else:
        acc_func = acc

    metrics = {
        "TP": get_true_pos,
        "TN": get_true_neg,
        "FP": get_false_pos,
        "FN": get_false_neg,
        "Accuracy": acc_func,
        "Prevalence": lambda y_true, y_pred, th: np.mean(y_true),
        "Sensitivity": lambda y_true, y_pred, th: recall_score(y_true, y_pred > th),
        "Specificity": lambda y_true, y_pred, th: recall_score(y_true, y_pred > th, pos_label=0),
        "PPV": lambda y_true, y_pred, th: precision_score(y_true, y_pred > th),
        "NPV": lambda y_true, y_pred, th: precision_score(y_true, y_pred > th, pos_label=0),
        "AUC": lambda y_true, y_pred, th: roc_auc_score(y_true, y_pred),
        "F1": lambda y_true, y_pred, th: f1_score(y_true, y_pred > th),
    }

    rows = []
    for i, label in enumerate(class_labels):
        row = {"Class": label}
        for metric_name, metric_func in metrics.items():
            try:
                if metric_name in ["TP", "TN", "FP", "FN"]:
                    value = metric_func(y[:, i], pred[:, i], thresholds[i])
                elif metric_name == "AUC":
                    value = metric_func(y[:, i], pred[:, i], None)  # th is not used
                else:
                    value = metric_func(y[:, i], pred[:, i], thresholds[i])
                
                row[metric_name] = round(value, 3)
            except Exception as e:
                row[metric_name] = f"Error: {str(e)}"
        
        row["Threshold"] = round(thresholds[i], 3)
        rows.append(row)

    df = pd.DataFrame(rows)
    return df.set_index("Class")

def print_confidence_intervals(class_labels, statistics):
    """
    Print confidence intervals for classification statistics.
    
    Args:
        class_labels: list of class names
        statistics: array of shape (n_classes, n_bootstrap_samples) with bootstrap samples
                   of the statistic (e.g., AUC) for each class
    
    Returns:
        DataFrame with mean and confidence intervals for each class
    """
    rows = []
    for i, label in enumerate(class_labels):
        try:
            if statistics.ndim == 2:
                # Handle case where statistics has shape (n_classes, n_bootstrap_samples)
                mean = np.mean(statistics[i, :])
                ci_lower = np.percentile(statistics[i, :], 5)
                ci_upper = np.percentile(statistics[i, :], 95)
            else:
                # Handle case where statistics has shape (n_classes, n_metrics, n_bootstrap_samples)
                mean = statistics.mean(axis=2)[i, 0]  # Assuming first metric is AUC
                ci_lower = np.percentile(statistics[i, 0, :], 5)
                ci_upper = np.percentile(statistics[i, 0, :], 95)
                
            rows.append({
                "Class": label,
                "Mean AUC (CI 5%-95%)": f"{mean:.2f} ({ci_lower:.2f}-{ci_upper:.2f})"
            })
        except Exception as e:
            rows.append({
                "Class": label,
                "Mean AUC (CI 5%-95%)": f"Error: {str(e)}"
            })
    
    return pd.DataFrame(rows).set_index("Class")

def get_curve(y, pred, class_labels, curve_type='roc', figsize=(10, 8)):
    """
    Wrapper function for plot_curve that returns the figure instead of displaying it.
    This matches the expected function name in the error message.
    
    Args:
        y: numpy array of shape (n_samples, n_classes) with ground truth labels
        pred: numpy array of shape (n_samples, n_classes) with prediction probabilities
        class_labels: list of class names
        curve_type: 'roc' or 'prc' for ROC or Precision-Recall curve respectively
        figsize: tuple specifying figure size
        
    Returns:
        matplotlib figure object
    """
    fig = plt.figure(figsize=figsize)
    
    # Set plot styling
    plt.grid(True, linestyle='--', alpha=0.7)
    
    for i, name in enumerate(class_labels):
        try:
            if curve_type.lower() == 'roc':
                fpr, tpr, _ = roc_curve(y[:, i], pred[:, i])
                auc_score = roc_auc_score(y[:, i], pred[:, i])
                plt.plot(fpr, tpr, label=f"{name} (AUC: {auc_score:.3f})", linewidth=2)
                plt.xlabel("False Positive Rate")
                plt.ylabel("True Positive Rate")
                plt.plot([0, 1], [0, 1], 'k--', alpha=0.5)  # Random performance line
                plt.title("ROC Curve")
                
            elif curve_type.lower() == 'prc':
                precision, recall, _ = precision_recall_curve(y[:, i], pred[:, i])
                avg_precision = average_precision_score(y[:, i], pred[:, i])
                # Plot from highest recall to lowest for better visualization
                plt.plot(recall, precision, label=f"{name} (AP: {avg_precision:.3f})", linewidth=2)
                plt.xlabel("Recall")
                plt.ylabel("Precision")
                # Add baseline at prevalence
                baseline = np.mean(y[:, i])
                plt.axhline(y=baseline, color='k', linestyle='--', alpha=0.5, 
                           label=f"Baseline ({baseline:.3f})" if i == 0 else "")
                plt.title("Precision-Recall Curve")
                
            else:
                raise ValueError("curve_type must be 'roc' or 'prc'.")
                
        except Exception as e:
            plt.text(0.5, 0.5, f"Error plotting {name}: {str(e)}", 
                    horizontalalignment='center', fontsize=12, color='red')
    
    # Improve legend and layout
    plt.legend(loc='best', frameon=True, fancybox=True, framealpha=0.8)
    plt.tight_layout()
    
    # Set axis limits
    if curve_type.lower() == 'roc':
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
    else:  # PRC
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
    
    return fig

def plot_curve(gt, pred, target_names, curve_type='roc', figsize=(10, 8)):
    """
    Plot ROC or Precision-Recall curves for multiple classes.
    
    Args:
        gt: numpy array of shape (n_samples, n_classes) with ground truth labels
        pred: numpy array of shape (n_samples, n_classes) with prediction probabilities
        target_names: list of class names
        curve_type: 'roc' or 'prc' for ROC or Precision-Recall curve respectively
        figsize: tuple specifying figure size
    """
    fig = get_curve(gt, pred, target_names, curve_type, figsize)
    plt.show()
    return fig